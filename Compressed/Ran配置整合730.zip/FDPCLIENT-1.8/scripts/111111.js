﻿var scriptName = "AutoLLLLL";
var scriptVersion = 1.2;
var scriptAuthor = "soulplexis";

var mobs = Java.type("net.minecraft.entity.EntityCreature");
var players = Java.type("net.minecraft.entity.player.EntityPlayer");

var autoMessage = new autoMessage();
var autoMessageClient;

function randomIntFrom(min, max) // Get a random integer from [min] to [max] 
{
    return Math.floor(Math.random() * (max - min + 1) + min);
}

function autoMessage() {
    var Mode = value.createList("办法", ["名字前讯息", "留言后的名字", "/msg", "没有名字", "随机侮辱"], "名字前讯息");
    var Mob = value.createBoolean("生物", false);
    var Player = value.createBoolean("人们 ", true);
	var AddFriend = value.createBoolean("/friend", true);
    var Instant = value.createBoolean("当他们死了并受到打击时就去做", true);
    var NoMove = value.createBoolean("移动时不发送", true);
	var ResetDelayOnMove = value.createBoolean("移动时要等待更长的时间", true);
    var Delay = value.createInteger("等待的时间 ", 10, 0, 100);
    var Message = value.createText("讯息", "@a你好~你被Ran击败!  ");
	var ClientName = value.createText("您程序的名称", "LiquidBounce");
    var realtarget;
    var deelay = 0;
    this.getName = function() {
        return "KillSay";
    };

    this.getDescription = function() {
        return "当目标死亡时，向他们发送一条消息。";
    };

    this.getCategory = function() {
        return "Fun";
    };
    this.onEnable = function() {
        target = null;
    }
    this.onMotion = function() {
		var insults = ["1"];	
		
		if(NoMove.get() && ResetDelayOnMove.get() && mc.gameSettings.keyBindForward.pressed || mc.gameSettings.keyBindLeft.pressed || mc.gameSettings.keyBindBack.pressed || mc.gameSettings.keyBindRight.pressed || mc.gameSettings.keyBindJump.pressed || mc.gameSettings.keyBindSneak.pressed) {
			deelay = 0;
		}
		if (target != null && (((target instanceof mobs && Mob.get() == true) || Mob.get() == false && !(target instanceof mobs)) || ((target instanceof players && Player.get() == true) || Player.get() == false && !(target instanceof players))) && ((Instant.get() == true && target.getHealth() == 0) || Instant.get() == false && target.isDead == true)) {
        deelay += 0.5;
		}
        if (deelay > Delay.get()) {
            if ((NoMove.get() && !mc.gameSettings.keyBindForward.pressed && !mc.gameSettings.keyBindLeft.pressed && !mc.gameSettings.keyBindBack.pressed && !mc.gameSettings.keyBindRight.pressed && !mc.gameSettings.keyBindJump.pressed && !mc.gameSettings.keyBindSneak.pressed) || NoMove.get() == false) {
                if (target != null && (((target instanceof mobs && Mob.get() == true) || Mob.get() == false && !(target instanceof mobs)) || ((target instanceof players && Player.get() == true) || Player.get() == false && !(target instanceof players))) && ((Instant.get() == true && target.getHealth() == 0) || Instant.get() == false && target.isDead == true)) {
                    switch (Mode.get()) {
                        case "留言后的名字":
                            mc.thePlayer.sendChatMessage(realtarget.getName() + " " + Message.get());
                            break;
                        case "名字前讯息":
                            mc.thePlayer.sendChatMessage(Message.get() + " " + realtarget.getName());
                            break;
                        case "/msg":
                            mc.thePlayer.sendChatMessage("/msg " + realtarget.getName() + " " + Message.get());
                            break;
                        case "没有名字":
                            mc.thePlayer.sendChatMessage(Message.get());
                            break;
						case "随机侮辱":
							mc.thePlayer.sendChatMessage(insults[randomIntFrom(0,insults.length - 1)]);
						break;
                    }
					if(AddFriend.get()) {
						mc.thePlayer.sendChatMessage("/friend add " + realtarget.getName());
					}
                    target = null;
                }
            }
            deelay = 0;
        }
    }
    this.addValues = function(values) {
        values.add(Message);
        values.add(Mode);
        values.add(Mob);
        values.add(Player);
        values.add(Delay);
        values.add(Instant);
        values.add(NoMove);
		values.add(ResetDelayOnMove);
		values.add(AddFriend);
    }
    var target;
    this.onAttack = function(event) {
        target = event.getTargetEntity();
        if (Player.get() && target instanceof players) {
            realtarget = target;
        }
        if (Mob.get() && target instanceof mobs) {
            realtarget = target;
        }
    }
}

function onLoad() {};

function onEnable() {
    autoMessageClient = moduleManager.registerModule(autoMessage);
};

function onDisable() {
    moduleManager.unregisterModule(autoMessageClient);
};