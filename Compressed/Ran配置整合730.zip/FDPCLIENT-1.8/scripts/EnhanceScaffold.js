/// api_version=2
// 我们绝不会在JS中参入任何恶意代码，您可以放心使用~
var script = registerScript({
	name: 'BW_MCHackerJS_EnhanceScaffold',
	version: '1.2',
	authors: ['Libws']
});
script.import('lib/timingFunctions.js');
script.import('lib/glFunctions.js');
script.import('lib/systemFunctions.js');

function CopyRight(Content_) {
	CopyRight_Core(Content_);

	function CopyRight_Core(Content) {
		var Prefix = 'BW_MCHacker';
		if (Content == undefined) {
			Content = '§e§l[' + Prefix + '] §bWelcome use ' + Prefix + '§r';
			var Say = 'I \'m ' + mc.getSession().getUsername() + ' and I proudly use ' + Prefix + ' to cheat!';
			Chat.print(Content);
			mc.thePlayer.sendChatMessage(Say);
		} else if (Content != undefined) {
			Content = '§e§l[' + Prefix + '] ' + Content + '§r';
			Chat.print(Content);
		}
	}
}
function Scaffold(Mode_, Name_, Values_) {
	if (Mode_ == 0) {
		return Scaffold_Core(Mode_, Name_, Values_);
	}
	Scaffold_Core(Mode_, Name_, Values_);

	function Scaffold_Core(Mode, Name, Values) {
		var Value, Scaffold = moduleManager.getModule('Scaffold');
		switch (Mode) {
			case 0:// Get
				Value = Scaffold.getValue(Name).get();
				break;
			case 1:// Set
				if (Scaffold.getState() == true) {
					Scaffold.getValue(Name).set(Values);
				}
				break;
			case 2:// Reduction
				Scaffold.getValue(Name).set(Values);
				break;
		}
		if (Value != undefined) {
			return Value;
		}
	}
}
function EnhanceScaffold(Mode_, Values_A_, Values_B_, Values_C_) {
	EnhanceScaffold_Core(Mode_, Values_A_, Values_B_, Values_C_);

	function EnhanceScaffold_Core(Mode, Values_A, Values_B, Values_C) {
		var Values;
		if (Values_A != 0 || Values_B != 0) {
			switch (Mode) {
				case 0:
					if (Values_A + Values_C <= 90 && Values_B + Values_C <= 90) {
						if (Values_A != Values_B) {
							Mode = 1;
							Name = 'AACYawOffset';
							RandValues_A = Values_A;
							RandValues_B = Values_B;
							if (RandValues_A > RandValues_B) {
								RandValues = RandomNumber(RandValues_B, RandValues_A);
							} else if (RandValues_A <= RandValues_B) {
								RandValues = RandomNumber(RandValues_A, RandValues_B);
							}
							Values = RandValues + Values_C;
						} else if (Values_A == Values_B) {
							RandValues_A = Values_A;
							RandValues_B = Values_B;
							Values = RandValues_A + Values_C;
						}
						Scaffold(Mode, Name, Values);
					} else if (Values_A + Values_C > 90 || Values_B + Values_C > 90) {
						CopyRight('§b发现您的AACYawOffset总设定值已超过限定值，为防止崩溃，已暂时停用此功能！');
					}
					break;
				case 1:
					if ((Values_A * 100 + Values_C * 100) <= 200 && (Values_B * 100 + Values_C * 100) <= 200) {
						if (Values_A != Values_B) {
							Mode = 1;
							Name = 'SpeedModifier';
							RandValues_A = Values_A * 100;
							RandValues_B = Values_B * 100;
							if (RandValues_A > RandValues_B) {
								RandValues = RandomNumber(RandValues_B, RandValues_A);
							} else if (RandValues_A <= RandValues_B) {
								RandValues = RandomNumber(RandValues_A, RandValues_B);
							}
							Values = RandValues / 100 + Values_C;
						} else if (Values_A == Values_C) {
							RandValues_A = Values_A;
							RandValues_B = Values_B;
							Values = RandValues_A + Values_C;
						}
						Scaffold(Mode, Name, Values);
					} else if ((Values_A * 100 + Values_C * 100) > 200 || (Values_B * 100 + Values_C * 100) > 200) {
						CopyRight('§b发现您的SpeedModifier总设定值已超过限定值，为防止崩溃，已暂时停用此功能！');
					}
					break;
			}
		}
	}
}
function RandomNumber(Min_, Max_) {
	return RandomNumber_Core(Min_, Max_);

	function RandomNumber_Core(Min, Max) {
		var RandomNumberValues;
		if (Min == undefined || Max == undefined) {
			RandomNumberValues = Math.round(Math.random() * 10);
			return RandomNumberValues;
		} else if (Min != undefined && Max != undefined) {
			RandomNumberValues = Math.floor(Math.random() * (Max - Min + 1)) + Min;
			return RandomNumberValues;
		}
	}
}
script.registerModule({
	name: 'EnhanceScaffold',
	description: '增强自动搭路',
	category: 'Fun',
	tag: 'XiaodaSense',
	settings: {
		RandomAACYawOffsetSwitch: Setting.boolean({
			name: 'RAACYO',
			default: false
		}),
		RandomAACYawOffsetDefault: Setting.integer({
			name: 'RAACYODefault',
			default: 0,
			min: 0,
			max: 90
		}),
		RandomAACYawOffset_A: Setting.integer({
			name: 'RAACYO-A',
			default: 0,
			min: 0,
			max: 90
		}),
		RandomAACYawOffset_B: Setting.integer({
			name: 'RAACYO-B',
			default: 0,
			min: 0,
			max: 90
		}),
		RandomAACYawOffset_C: Setting.integer({
			name: 'RAACYO-C',
			default: 0,
			min: 0,
			max: 90
		}),
		RandomSpeedModifierSwitch: Setting.boolean({
			name: 'RSM',
			default: false
		}),
		RandomSpeedModifierDefault: Setting.float({
			name: 'RSMDefault',
			default: 1.00,
			min: 0.00,
			max: 2.00
		}),
		RandomSpeedModifier_A: Setting.float({
			name: 'RSM-A',
			default: 1.00,
			min: 0.00,
			max: 2.00
		}),
		RandomSpeedModifier_B: Setting.float({
			name: 'RSM-B',
			default: 1.00,
			min: 0.00,
			max: 2.00
		}),
		RandomSpeedModifier_C: Setting.float({
			name: 'RSM-C',
			default: 0.00,
			min: 0.00,
			max: 2.00
		})
	}
}, function (module) {
	module.on('load', function () {
		CopyRight('§eEnhanceScaffold is §lLoad');
	});
	module.on('enable', function () {
		CopyRight('§aEnhanceScaffold is §lEnable');
	});
	module.on('disable', function () {
		if (module.settings.RandomAACYawOffsetSwitch.get() == true) {
			Scaffold(2, 'AACYawOffset', module.settings.RandomAACYawOffsetDefault.get());
		}
		if (module.settings.RandomSpeedModifierSwitch.get() == true) {
			Scaffold(2, 'SpeedModifier', module.settings.RandomSpeedModifierDefault.get());
		}
		CopyRight('§cEnhanceScaffold is §lDisable');
	});
	module.on('update', function () {
		if (module.settings.RandomAACYawOffsetSwitch.get() == true) {
			EnhanceScaffold(0, module.settings.RandomAACYawOffset_A.get(), module.settings.RandomAACYawOffset_B.get(), module.settings.RandomAACYawOffset_C.get());
		}
		if (module.settings.RandomSpeedModifierSwitch.get() == true) {
			EnhanceScaffold(1, module.settings.RandomSpeedModifier_A.get(), module.settings.RandomSpeedModifier_B.get(), module.settings.RandomSpeedModifier_C.get());
		}
	});
});