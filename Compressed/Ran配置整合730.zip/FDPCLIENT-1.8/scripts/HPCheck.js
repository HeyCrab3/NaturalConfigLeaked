/// api_version=2
var script = registerScript({
	name: "BW_MCHackerJS_HPChecker",
	version: "1.0",
	authors: ["Libws"]
});
var BW_MCHackerJS_HPChecker_Fonts = Java.type("net.ccbluex.liquidbounce.ui.font.Fonts");
var BW_MCHackerJS_HPChecker_Color = Java.type("java.awt.Color");
var BW_MCHackerJS_HPChecker_ScaledResolution = Java.type("net.minecraft.client.gui.ScaledResolution");
var BW_MCHackerJS_HPChecker_White = new BW_MCHackerJS_HPChecker_Color(255, 255, 255).getRGB();

function BW_MCHackerJS_HPChecker_QZ1(int){
	return(int - int % 1);
}
function BW_MCHackerJS_HPChecker_QZ2(int){
	return(Math.round(int * 10)) ;
}
script.registerModule({
	name: "HPChecker",
	description: "检测血量",
    category: "Render",
    tag: "BW_MCHackerJS",
}, function (module) {
    var BW_MCHackerJS_HPChecker_LastX,BW_MCHackerJS_HPChecker_LastZ,BW_MCHackerJS_HPChecker_MCUIWidth,BW_MCHackerJS_HPChecker_MCUIHeight,BW_MCHackerJS_HPChecker_HPCSTR="0 HP";
	var BW_MCHackerJS_HPChecker_HP = 20,BW_MCHackerJS_HPChecker_HPC;
	module.on("enable", function()
    {
        Chat.print("§e§l[BW_MCHacker] §aBW_MCHackerJS_HPChecker is §lEnable§r");
    });
    module.on("update", function () {
		var BW_MCHackerJS_HPChecker_SR = new BW_MCHackerJS_HPChecker_ScaledResolution(mc);
		BW_MCHackerJS_HPChecker_MCUIWidth = BW_MCHackerJS_HPChecker_SR.getScaledWidth();
		BW_MCHackerJS_HPChecker_MCUIHeight = BW_MCHackerJS_HPChecker_SR.getScaledHeight();
        BW_MCHackerJS_HPChecker_LastX = mc.thePlayer.posX;
        BW_MCHackerJS_HPChecker_LastZ = mc.thePlayer.posZ;
        BW_MCHackerJS_HPChecker_HPC = BW_MCHackerJS_HPChecker_QZ2(BW_MCHackerJS_HPChecker_HP-mc.thePlayer.getHealth()) / 10;
        if (BW_MCHackerJS_HPChecker_HPC > 0) {BW_MCHackerJS_HPChecker_HPCSTR = "§e§l[BW_MCHacker] §b- §c§l" + BW_MCHackerJS_HPChecker_HPC + "§r§b HP§r";}
        if (BW_MCHackerJS_HPChecker_HPC < 0) {BW_MCHackerJS_HPChecker_HPCSTR = "§e§l[BW_MCHacker] §b+ §a§l" + -BW_MCHackerJS_HPChecker_HPC + "§r§b HP§r";}
        if (BW_MCHackerJS_HPChecker_HPC != 0) {Chat.print(BW_MCHackerJS_HPChecker_HPCSTR);}
        BW_MCHackerJS_HPChecker_HP = mc.thePlayer.getHealth();
    });
   // module.on("attack", function(eventData) {
   //     Chat.print("attack\n");
   // });
    module.on("render2D", function() {
		BW_MCHackerJS_HPChecker_Fonts.minecraftFont.drawString(BW_MCHackerJS_HPChecker_QZ1(mc.thePlayer.getHealth()),(BW_MCHackerJS_HPChecker_MCUIWidth / 2),(BW_MCHackerJS_HPChecker_MCUIHeight / 2) - 30,BW_MCHackerJS_HPChecker_White);
	});
});