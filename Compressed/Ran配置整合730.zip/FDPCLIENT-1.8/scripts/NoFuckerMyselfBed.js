var scriptName = "BW_MCHackerJS_NoFuckerMyselfBed";
var scriptVersion = 1.0;
var scriptAuthor = "Libws";
script.import('lib/minecraftUtils.js');
script.import('lib/timingFunctions.js');
script.import('lib/glFunctions.js');
script.import('lib/systemFunctions.js'); 
var BW_MCHackerJS_NoFuckerMyselfBed_S02PacketChat = Java.type('net.minecraft.network.play.server.S02PacketChat');
var BW_MCHackerJS_NoFuckerMyselfBed_FuckerModule = moduleManager.getModule("Fucker");
var BW_MCHackerJS_NoFuckerMyselfBed_Core = new BW_MCHackerJS_NoFuckerMyselfBed_Core();
var BW_MCHackerJS_NoFuckerMyselfBed_Core_API;

function BW_MCHackerJS_NoFuckerMyselfBed_Core() {
    var BW_MCHackerJS_NoFuckerMyselfBed_BlockIDList = [26];
    var BW_MCHackerJS_NoFuckerMyselfBed_Block = Java.type('net.minecraft.block.Block');
    var BW_MCHackerJS_NoFuckerMyselfBed_BlockPos = Java.type("net.minecraft.util.BlockPos");
    var BW_MCHackerJS_NoFuckerMyselfBed_BlockUtils = Java.type('net.ccbluex.liquidbounce.utils.block.BlockUtils');
    var BW_MCHackerJS_NoFuckerMyselfBed_TargetX;
    var BW_MCHackerJS_NoFuckerMyselfBed_TargetY;
    var BW_MCHackerJS_NoFuckerMyselfBed_TargetZ;
    function BW_MCHackerJS_NoFuckerMyselfBed_GetClosestBlock(BW_MCHackerJS_NoFuckerMyselfBed_POSX, BW_MCHackerJS_NoFuckerMyselfBed_POSY, BW_MCHackerJS_NoFuckerMyselfBed_POSZ, BW_MCHackerJS_NoFuckerMyselfBed_BLPList) {
        BW_MCHackerJS_NoFuckerMyselfBed_BLPList.sort(function (a, b) {
            var BW_MCHackerJS_NoFuckerMyselfBed_DistanceA = a.distanceSqToCenter(BW_MCHackerJS_NoFuckerMyselfBed_POSX, BW_MCHackerJS_NoFuckerMyselfBed_POSY, BW_MCHackerJS_NoFuckerMyselfBed_POSZ);
            var BW_MCHackerJS_NoFuckerMyselfBed_DistanceB = b.distanceSqToCenter(BW_MCHackerJS_NoFuckerMyselfBed_POSX, BW_MCHackerJS_NoFuckerMyselfBed_POSY, BW_MCHackerJS_NoFuckerMyselfBed_POSZ);
            return BW_MCHackerJS_NoFuckerMyselfBed_DistanceA - BW_MCHackerJS_NoFuckerMyselfBed_DistanceB;
        });
        return BW_MCHackerJS_NoFuckerMyselfBed_BLPList[0];
    }
    function BW_MCHackerJS_NoFuckerMyselfBed_UpdateCloestBlockPos() {
		var BW_MCHackerJS_NoFuckerMyselfBed_POSX = mc.thePlayer.posX;
        var BW_MCHackerJS_NoFuckerMyselfBed_POSY = mc.thePlayer.posY;
        var BW_MCHackerJS_NoFuckerMyselfBed_POSZ = mc.thePlayer.posZ;
        var BW_MCHackerJS_NoFuckerMyselfBed_TargetBlockList = [];
        var BW_MCHackerJS_NoFuckerMyselfBed_SearchDistance = 20;
        for (var BW_MCHackerJS_NoFuckerMyselfBed_SearchX = BW_MCHackerJS_NoFuckerMyselfBed_POSX - BW_MCHackerJS_NoFuckerMyselfBed_SearchDistance; BW_MCHackerJS_NoFuckerMyselfBed_SearchX < BW_MCHackerJS_NoFuckerMyselfBed_POSX + BW_MCHackerJS_NoFuckerMyselfBed_SearchDistance; BW_MCHackerJS_NoFuckerMyselfBed_SearchX++) {
            for (var BW_MCHackerJS_NoFuckerMyselfBed_SearchY = BW_MCHackerJS_NoFuckerMyselfBed_POSY - BW_MCHackerJS_NoFuckerMyselfBed_SearchDistance; BW_MCHackerJS_NoFuckerMyselfBed_SearchY < BW_MCHackerJS_NoFuckerMyselfBed_POSY + BW_MCHackerJS_NoFuckerMyselfBed_SearchDistance; BW_MCHackerJS_NoFuckerMyselfBed_SearchY++) {
                for (var BW_MCHackerJS_NoFuckerMyselfBed_SearchZ = BW_MCHackerJS_NoFuckerMyselfBed_POSZ - BW_MCHackerJS_NoFuckerMyselfBed_SearchDistance; BW_MCHackerJS_NoFuckerMyselfBed_SearchZ < BW_MCHackerJS_NoFuckerMyselfBed_POSZ + BW_MCHackerJS_NoFuckerMyselfBed_SearchDistance; BW_MCHackerJS_NoFuckerMyselfBed_SearchZ++) {
                    var BW_MCHackerJS_NoFuckerMyselfBed_BLP = new BW_MCHackerJS_NoFuckerMyselfBed_BlockPos(BW_MCHackerJS_NoFuckerMyselfBed_SearchX, BW_MCHackerJS_NoFuckerMyselfBed_SearchY, BW_MCHackerJS_NoFuckerMyselfBed_SearchZ);
                    if (!mc.theWorld.isAirBlock(BW_MCHackerJS_NoFuckerMyselfBed_BLP)) {
                        var BW_MCHackerJS_NoFuckerMyselfBed_BlockID = BW_MCHackerJS_NoFuckerMyselfBed_Block.getIdFromBlock(BW_MCHackerJS_NoFuckerMyselfBed_BlockUtils.getBlock(BW_MCHackerJS_NoFuckerMyselfBed_BLP));
                        if (BW_MCHackerJS_NoFuckerMyselfBed_BlockIDList.indexOf(BW_MCHackerJS_NoFuckerMyselfBed_BlockID) != -1) {
                            BW_MCHackerJS_NoFuckerMyselfBed_TargetBlockList.push(BW_MCHackerJS_NoFuckerMyselfBed_BLP);
                        }
                    }
                }
            }
        }
        if (BW_MCHackerJS_NoFuckerMyselfBed_TargetBlockList.length == 0) {
            BW_MCHackerJS_NoFuckerMyselfBed_TargetX = null;
            BW_MCHackerJS_NoFuckerMyselfBed_TargetY = null;
            BW_MCHackerJS_NoFuckerMyselfBed_TargetZ = null;
        }else{
            var BW_MCHackerJS_NoFuckerMyselfBed_CloestBLP = BW_MCHackerJS_NoFuckerMyselfBed_GetClosestBlock(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, BW_MCHackerJS_NoFuckerMyselfBed_TargetBlockList);
            BW_MCHackerJS_NoFuckerMyselfBed_TargetX = BW_MCHackerJS_NoFuckerMyselfBed_CloestBLP.getX();
            BW_MCHackerJS_NoFuckerMyselfBed_TargetY = BW_MCHackerJS_NoFuckerMyselfBed_CloestBLP.getY();
            BW_MCHackerJS_NoFuckerMyselfBed_TargetZ = BW_MCHackerJS_NoFuckerMyselfBed_CloestBLP.getZ();
            chat.print("§e§l[Ran] §b已经成功标记您的床，靠近将自动关闭Fucker§r");
        }
    }    
	this.getName = function() {
        return "NoFuckerMyselfBed";
    };
    this.getDescription = function() {
        return "防止Fucker挖自己队的床";
    };
    this.getCategory = function() {
        return "World";
    };
    this.getTag = function() {
		return "BW_MCHackerJS";
	};
    this.onEnable = function() {
        BW_MCHackerJS_NoFuckerMyselfBed_TargetX = null;
        BW_MCHackerJS_NoFuckerMyselfBed_TargetY = null;
        BW_MCHackerJS_NoFuckerMyselfBed_TargetZ = null;
        chat.print("§e§l[BW_MCHacker] §aBW_MCHackerJS_NoFuckerMyselfBed is §lEnable§r");
	};
	this.onPacket = function(event) {
	var BW_MCHackerJS_NoFuckerMyselfBed_Packet = event.getPacket();
	if(BW_MCHackerJS_NoFuckerMyselfBed_Packet instanceof BW_MCHackerJS_NoFuckerMyselfBed_S02PacketChat) {
        if (BW_MCHackerJS_NoFuckerMyselfBed_Packet.getChatComponent().getUnformattedText().contains("游戏开始 ...") || BW_MCHackerJS_NoFuckerMyselfBed_Packet.getChatComponent().getUnformattedText().contains("开始战斗吧")) {
            BW_MCHackerJS_NoFuckerMyselfBed_TargetX = null;
            BW_MCHackerJS_NoFuckerMyselfBed_TargetY = null;
            BW_MCHackerJS_NoFuckerMyselfBed_TargetZ = null;
		    }
	    }
	};
    this.onUpdate = function() {
		if (BW_MCHackerJS_NoFuckerMyselfBed_TargetX == null) {
			BW_MCHackerJS_NoFuckerMyselfBed_UpdateCloestBlockPos();
		} else {
			if (mc.thePlayer.posZ.toFixed(0).toString() > BW_MCHackerJS_NoFuckerMyselfBed_TargetZ - 10 && mc.thePlayer.posZ.toFixed(0).toString() < BW_MCHackerJS_NoFuckerMyselfBed_TargetZ + 10 && mc.thePlayer.posX.toFixed(0).toString() > BW_MCHackerJS_NoFuckerMyselfBed_TargetX - 10 && mc.thePlayer.posX.toFixed(0).toString() < BW_MCHackerJS_NoFuckerMyselfBed_TargetX + 10) {
			    BW_MCHackerJS_NoFuckerMyselfBed_FuckerModule.setState(false);
		    } else {
			    BW_MCHackerJS_NoFuckerMyselfBed_FuckerModule.setState(true);
	        }
	    }
	};
    this.onDisable = function () {
        BW_MCHackerJS_NoFuckerMyselfBed_FuckerModule.setState(false);
        chat.print("§e§l[BW_MCHacker] §cBW_MCHackerJS_NoFuckerMyselfBed is §lDisable§r");
    };
}
function onLoad() {}
function onEnable() {
    BW_MCHackerJS_NoFuckerMyselfBed_Core_API = moduleManager.registerModule(BW_MCHackerJS_NoFuckerMyselfBed_Core);
}
function onDisable() {
    moduleManager.unregisterModule(BW_MCHackerJS_NoFuckerMyselfBed_Core_API);
}