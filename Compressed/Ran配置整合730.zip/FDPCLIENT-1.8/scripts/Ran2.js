﻿var scriptName = "Mainjs";
var scriptVersion = 4.0;
var scriptAuthor = "WangHang";

var Mainjs;
var Mainjs = new Mainjs();
function Mainjs () {
	this.getName = function() {
		return "----Ran16Config----";
};

	this.getDescription = function() {
		return "Ran on Top ";
	};
	
	this.getCategory = function() {
		return "Misc";
	};
		
	this.onEnable = function() {
		chat.print("&6[Ran]我要娶张雨菲！");
	}
	
}
function onEnable() {
	Mainjs = moduleManager.registerModule(Mainjs);
};

function onDisable() {
	moduleManager.unregistermodule(Mainjs);
};

