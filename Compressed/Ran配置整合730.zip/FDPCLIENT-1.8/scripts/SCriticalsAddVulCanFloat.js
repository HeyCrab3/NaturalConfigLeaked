//作者 By 小手冰凉 倒卖亲妈被人反复轮J
var scriptName = "SCrit";
var scriptVersion = 1.5;
var scriptAuthor = "XiaoShouBingLiang 1.5";

var C03PacketPlayer = Java.type('net.minecraft.network.play.client.C03PacketPlayer');
var C04PacketPlayerPosition = Java.type('net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition');
var C06 = Java.type('net.minecraft.network.play.client.C03PacketPlayer.C06PacketPlayerPosLook');
var EntityLivingBase = Java.type('net.minecraft.entity.EntityLivingBase');
var SCr = new SCr();
var client;

function SCr() {
    //嘉然 我真的好喜欢你啊 为了你 我要开G！
    //东雪莲：骂谁狗罕见呢？
    //七海：我耳机呢？
    //还原神州 中华为国 胡桃猪肚汤 核桃花生猪尾汤 巧可莉
    //XinXin Or GM And 凌晨114514？
    var CritMode = value.createList("CriticalsMode", ["Packet", "Hyp", "Custom", "NCPPacket", "LowHop" ,"AAC5Motion" ,"Visual" ,"VulCanHop", "VulCanFloat" ,"AACPacket" , "LingCheng"], "Packet");
    var MotionY = value.createFloat("CustomMotionY", 0, 0, 1);
    var PacketMode = value.createList("PacketMode", ["C04","C06"] , "C06") //AAC5Motion VulCan Custom都是MotionY 跟C04 C06无关 不受影响 即使换PacketMode模式
    var attacks = 0;

    this.getName = function() {
        return "SCriticals";
    };

    this.getTag = function() {
        return "CritMode:" + CritMode.get() + ",PacketMode:" + PacketMode.get();
    };

    this.getDescription = function() {
        return "CritBoost!";
    };

    this.getCategory = function() {
        return "Combat";
    };

    this.addValues = function(values) {
        values.add(CritMode);
        values.add(MotionY);
        values.add(PacketMode);
    }

    this.onEnable = function() {
        attacks = 0;
    }

    this.onAttack = function (event) {
        if (event.getTargetEntity() instanceof EntityLivingBase) {
            entity = event.getTargetEntity();
        }

        if(PacketMode.get() == "C04"){
        switch (CritMode.get()) {
            case "Packet":
                mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.08, mc.thePlayer.posZ, true))
                mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, false))
                break;
            case "Hyp":
                mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.04132332, mc.thePlayer.posZ, false))
                mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.023243243674, mc.thePlayer.posZ, false))
                mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.01, mc.thePlayer.posZ, false))
                mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.0011, mc.thePlayer.posZ, false))
                break;
            case "Custom":
                if(mc.thePlayer.onGround || isOnGround(0.5)){
                    mc.thePlayer.jump(); //JS里必须加这个 不然人物一直持续上升
                    mc.thePlayer.motionY = MotionY.get();
                }
                break;
            case "AACPacket": //罚站刀爆
                mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.05250000001304, mc.thePlayer.posZ, false))
                mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.00150000001304, mc.thePlayer.posZ, false))
                mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.01400000001304, mc.thePlayer.posZ, false))
                mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.00150000001304, mc.thePlayer.posZ, false))
                break;
            case "NCPPacket":
                mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.11, mc.thePlayer.posZ, false))
                mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.1100013579, mc.thePlayer.posZ, false))
                mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.0000013579, mc.thePlayer.posZ, false))
                break;
            case "AAC5Motion":
                if(mc.thePlayer.onGround || isOnGround(0.5)){
                    mc.thePlayer.jump(); //JS里必须加这个 不然人物一直持续上升
                    mc.thePlayer.motionY = 0.15;
                }
                break;
            case "VulCanHop": //Bypss is 止于
                if(mc.thePlayer.onGround || isOnGround(0.5)){
                    mc.thePlayer.jump();
                    mc.thePlayer.motionY = 0.21;
                }
                break;
            case "Visual":
                //这是个假刀爆 给你看的
                mc.thePlayer.onCriticalHit(entity)
                break;
            case "LingCheng":
                mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.0114514, mc.thePlayer.posZ, true))
                mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, false))
                break;
            case "LowHop":
                if (mc.thePlayer.onGround || isOnGround(0.5)) {
                    mc.thePlayer.jump();
                    mc.thePlayer.motionY = 0.1;
                }
                break;
            case "VulCanFloat": //Float is FDPClient
                attacks++;
                if(attacks > 6) {
                    mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.02, mc.thePlayer.posZ, false))
                    mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.1216, mc.thePlayer.posZ, false))
                    attacks = 0;
                }
                break;
            }
        }else{
            switch (CritMode.get()) {
                case "Packet":
                    mc.thePlayer.sendQueue.addToSendQueue(new C06(mc.thePlayer.posX, mc.thePlayer.posY + 0.08, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, true))
                    mc.thePlayer.sendQueue.addToSendQueue(new C06(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false))
                    break;
                case "Hyp":
                    mc.thePlayer.sendQueue.addToSendQueue(new C06(mc.thePlayer.posX, mc.thePlayer.posY + 0.04132332, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false))
                    mc.thePlayer.sendQueue.addToSendQueue(new C06(mc.thePlayer.posX, mc.thePlayer.posY + 0.023243243674, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false))
                    mc.thePlayer.sendQueue.addToSendQueue(new C06(mc.thePlayer.posX, mc.thePlayer.posY + 0.01, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false))
                    mc.thePlayer.sendQueue.addToSendQueue(new C06(mc.thePlayer.posX, mc.thePlayer.posY + 0.0011, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false))
                    break;
                case "Custom":
                    if (mc.thePlayer.onGround || isOnGround(0.5)) {
                        mc.thePlayer.jump(); //JS里必须加这个 不然人物一直持续上升
                        mc.thePlayer.motionY = MotionY.get();
                    }
                    break;
                case "AACPacket": //罚站刀爆
                    mc.thePlayer.sendQueue.addToSendQueue(new C06(mc.thePlayer.posX, mc.thePlayer.posY + 0.05250000001304, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false))
                    mc.thePlayer.sendQueue.addToSendQueue(new C06(mc.thePlayer.posX, mc.thePlayer.posY + 0.00150000001304, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false))
                    mc.thePlayer.sendQueue.addToSendQueue(new C06(mc.thePlayer.posX, mc.thePlayer.posY + 0.01400000001304, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false))
                    mc.thePlayer.sendQueue.addToSendQueue(new C06(mc.thePlayer.posX, mc.thePlayer.posY + 0.00150000001304, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false))
                    break;
                case "NCPPacket":
                    mc.thePlayer.sendQueue.addToSendQueue(new C06(mc.thePlayer.posX, mc.thePlayer.posY + 0.11, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false))
                    mc.thePlayer.sendQueue.addToSendQueue(new C06(mc.thePlayer.posX, mc.thePlayer.posY + 0.1100013579, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false))
                    mc.thePlayer.sendQueue.addToSendQueue(new C06(mc.thePlayer.posX, mc.thePlayer.posY + 0.0000013579, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false))
                    break;
                case "AAC5Motion":
                    if (mc.thePlayer.onGround || isOnGround(0.5)) {
                        mc.thePlayer.jump(); //JS里必须加这个 不然人物一直持续上升
                        mc.thePlayer.motionY = 0.15;
                    }
                    break;
                case "VulCanHop": //Bypss is 止于
                    if (mc.thePlayer.onGround || isOnGround(0.5)) {
                        mc.thePlayer.jump();
                        mc.thePlayer.motionY = 0.21;
                    }
                    break;
                case "Visual":
                    //这是个假刀爆 给你看的
                    mc.thePlayer.onCriticalHit(entity)
                    break;
                case "LingCheng":
                    mc.thePlayer.sendQueue.addToSendQueue(new C06(mc.thePlayer.posX, mc.thePlayer.posY + 0.0114514, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, true))
                    mc.thePlayer.sendQueue.addToSendQueue(new C06(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false))
                    break;
                case "LowHop":
                    if (mc.thePlayer.onGround || isOnGround(0.5)) {
                        mc.thePlayer.jump();
                        mc.thePlayer.motionY = 0.1;
                    }
                    break;
                case "VulCanFloat": //Float is FDPClient
                    attacks++;
                    if(attacks > 6) {
                        mc.thePlayer.sendQueue.addToSendQueue(new C06(mc.thePlayer.posX, mc.thePlayer.posY + 0.02, mc.thePlayer.posZ, false))
                        mc.thePlayer.sendQueue.addToSendQueue(new C06(mc.thePlayer.posX, mc.thePlayer.posY + 0.1216, mc.thePlayer.posZ, false))
                        attacks = 0;
                    }
                    break;
            }
        }
    };
}

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(SCr);
}

function onDisable() {
    moduleManager.unregisterModule(client);
}