var scriptName = "VulcanCriticals";
var scriptAuthor = "Ran";
var scriptVersion = 1.0;
var FakeVulcanCriticals_Core = new FakeVulcanCriticals_Core();
var FakeVulcanCriticals_Core_API;

function FakeVulcanCriticals_Core() {
    this.getName = function () {
        return "VulcanCriticals";
    };
    this.getDescription = function () {
        return "用于火神反作弊的刀暴";
    };
    this.getCategory = function () {
        return "Combat";
    };
    this.getTag = function() {
        return "FakeJS";
    };
    this.onAttack = function (event) {
        mc.thePlayer.motionY = 0.04;
    };
}
function onEnable() {
    disablerModuleClient = moduleManager.registerModule(FakeVulcanCriticals_Core);
}
function onDisable() {
    moduleManager.unregisterModule(FakeVulcanCriticals_Core_API);
}