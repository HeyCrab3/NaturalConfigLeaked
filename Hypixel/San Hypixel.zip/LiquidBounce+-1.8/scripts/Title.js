﻿var scriptName = "Title"
var scriptVersion = 3.0
var scriptAuthor = "LaoTong"

var Title = new Title()
var client

function Title() {
	var S = 0
	var HM = 0
	var M =0
	var H = 0
	
	this.getName = function() {
        return "Title"
    }

    this.getDescription = function() {
        return "Title"
    }

    this.getCategory = function() {
        return "Fun"
    }

    this.onUpdate = function() {
		 HM += 1
		 if (HM ==20){
		   S = S + 1
		   HM = 0
		   
		  }
		 if (S ==60){
		   M = M +1
		   S = 0
		  }
		  if (M==60){
		   H = H+1
		   M = 0
		  }
		Display.setTitle('  Insane Hypixel 220701||“开你妈逼挂呢天天就知道开开开，魔怔了是不是——鸽子”|| 您已奔放：'+H+'时'+M+'分'+S+'秒')
	}
}

var Display = Java.type('org.lwjgl.opengl.Display')

function onLoad() {}
w
function onEnable() {
    client = moduleManager.registerModule(Title)
}

function onDisable() {
    moduleManager.unregisterModule(client)
}