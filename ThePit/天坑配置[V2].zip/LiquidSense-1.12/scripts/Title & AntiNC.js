﻿var scriptName = "title";
var scriptVersion = 1.0;
var scriptAuthor = "AquaVit、FunkNight";
//Frances修改
var Random = Java.type('java.util.Random');
var Display = Java.type('org.lwjgl.opengl.Display')

var Debug = new Debug();
var client;

function Debug() {
	var HM,H,M,S;
	var random = new Random();
    var a = random.nextInt(25); 
    this.getName = function() {
        return "Title & AntiNC ";
    };

    this.getDescription = function() {
        return "Insane";
    };

    this.getCategory = function() {
        return "Fun";
    };
	
	this.getTag = function() {
		return "Timer";
	}
    this.onEnable = function() {
		HM = 0;
		H = 0;
		M = 0;
		S = 0;
    }
    this.onUpdate = function() {
		HM += 1;
        if (HM == 20){
			S = S + 1;
			HM = 0;
		}
        if (S == 60){
		    M = M + 1;
			S = 0;
			chat.print(" -----------------------------------------------")
			chat.print("§1     您目前使用的配置是San天坑配置      ")
			chat.print("§6     配置作者:Yurlu")
			chat.print("§5===========================")
			chat.print("§8 R-杀戮+反击退 X-刀爆   ")
			chat.prin("§5===========================")
			chat.print("§6游戏时间已过" + "时间已流失"+ H  +"时"  + M +"分")
			chat.print("§9祝您游戏愉快。")
			chat.print("§b一定要带点iq玩哦。")
                                                chat.print("§6Have a Good Time!")
			chat.print(" ----------------------------------------------")
		}
        if (M == 60){
            H = H + 1;
			M = 0;
		}			
		switch (a){
			case 1:
                Display.setTitle("Insane |  Good Conifg  |"+ ' 您已游玩 '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 2:
                Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流逝 '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 3:
                Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 4:
                Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 5:
                Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 6:
                Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 7:
                Display.setTitle("Insane |  Good Conifg |"+ ' 时间已流失'+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 8:
                Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流失'+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 9:
                Display.setTitle("Insane |  Good Conifg |"+ ' 时间已流失'+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 10:
                Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 11:
                Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 12:
                Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
                break;
	case 13:
	Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		break;
		case 14:
		    Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
		case 15:
		    Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
		case 16:
		    Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
		case 17:
		    Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
		case 18:
		    Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
		case 19:
		    Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
		case 20:
		    Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
		case 21:
		    Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
		case 22:
		    Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
		case 23:
		    Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
		case 24:
		    Display.setTitle("Insane |  Good Conifg  |"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
            default:
        }
	}
    this.onDisable = function () {	
	}
}

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(Debug);
}

function onDisable() {
    moduleManager.unregisterModule(client);
}
