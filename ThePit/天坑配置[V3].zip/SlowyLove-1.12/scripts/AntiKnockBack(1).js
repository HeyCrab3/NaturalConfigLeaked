﻿/// api_version=2
var script = registerScript({
    name: "反击退",
    version: "2.1",
    authors: ["Insane"]
});

var S27PacketExplosion = Java.type('net.minecraft.network.play.server.S27PacketExplosion');
var S12PacketEntityVelocity = Java.type('net.minecraft.network.play.server.S12PacketEntityVelocity');
var C03PacketPlayer = Java.type("net.minecraft.network.play.client.C03PacketPlayer");
var velocityInput = false;
var jump = false;
var Entity = Java.type("net.minecraft.entity.Entity");
var Random = Java.type('java.util.Random');
var Combating = false
var DisableReset = false;

script.registerModule({
    name: "NewVelocity",
    category: "Combat",
    description: "KanaeVelocity",
    settings: {
        mode: Setting.list({
            name: "Mode",
            default: "Simple",
            values: ["Simple", "Cancel", "Clean", "Push", "Jitter", "HytSpoof", "AAC5Simple", "HytTest", "HytTest2", "HytTest3", "HytTest4", "HytNew"]
        }),
        xVel: Setting.float({
            name: "X-Percentage",
            default: 0,
            min: -100,
            max: 100
        }),
        yVel: Setting.float({
            name: "Y-Percantage",
            default: 0,
            min: -100,
            max: 100
        }),
        zVel: Setting.float({
            name: "Z-Percentage",
            default: 0,
            min: -100,
            max: 100
        }),
        SimpleCancel: Setting.boolean({
            name: "SimpleCancel",
            default: true
        }),
        HeightValue: Setting.float({
            name: "AAC5Simple-Height",
            default: 0.5,
            min: 0.0,
            max: 1.0
        }),
        hytOnlyGround: Setting.boolean({
            name: "AAC5Simple-OnlyGround",
            default: true
        }),
        simpleValue: Setting.boolean({
            name: "SimpleGround",
            default: true
        }),
        c03packet: Setting.boolean({
            name: "HytNewC03Packet",
            default: false
        }),
        cancelS27: Setting.boolean({
            name: "CancelS27",
            default: false
        }),		
        debug: Setting.boolean({
            name: "Debug",
            default: false
        }),
        disreset: Setting.boolean({
            name: "DisableReset",
            default: false
        }),
        disreset2: Setting.boolean({
            name: "DisableReset[Packet]",
            default: false
        })		
    }
}, function(module) {
    var var1 = mc.thePlayer

    function Jitter() {
        var random = new Random();
        var jitterCheck = random.nextInt(5);
        if (Combating) {
            mc.timer.timerSpeed = 0.81286457875
            switch (jitterCheck) {
                case 1:
                    mc.thePlayer.motionX *= 0.0087048710342
                    mc.thePlayer.motionZ *= 0.0087048710342
                    mc.thePlayer.motionY *= 0.659973236764689
                    break;
                case 2:
                    mc.thePlayer.motionX *= 0.0088041410129
                    mc.thePlayer.motionZ *= 0.0088041410129
                    mc.thePlayer.motionY *= 0.659973236764689
                    break;
                case 3:
                    mc.thePlayer.motionX *= 0.00951043207
                    mc.thePlayer.motionZ *= 0.00951043207
                    mc.thePlayer.motionY *= 0.659973236764689
                    break;
                case 4:
                    mc.thePlayer.motionX *= 0.009545643206
                    mc.thePlayer.motionZ *= 0.009545643206
                    mc.thePlayer.motionY *= 0.659973236764689
                    break;
            }
        }
    }

    module.on("attack", function(event) {
        Combating = true
    });

    module.on("update", function() {
        module.tag = module.settings.mode.get()
        if (module.settings.mode.get() == "Jitter") {
            if ((mc.thePlayer.hurtTime <= 0 || mc.thePlayer.onGround) && !Combating) {
                mc.timer.timerSpeed = 1
            }
            if (mc.thePlayer.hurtTime > 0) {
                Jitter()
            }
        }

        if (mc.thePlayer.isInWater || mc.thePlayer.isInLava || mc.thePlayer.isInWeb) return;
        switch (module.settings.mode.get()) {
            case "HytSpoof":
                if (mc.thePlayer.hurtTime <= 0 && !velocityInput) {
                    return
                }
                mc.thePlayer.motionX *= 0.91111166007777
                mc.thePlayer.motionZ *= 0.87681111233666
                mc.netHandler.addToSendQueue(new C0BPacketEntityAction(var1, C0BPacketEntityAction.Action.START_SPRINTING))
                velocityInput = false
                break;
            case "HytTest":
                if (mc.thePlayer.hurtTime <= 0 && !velocityInput) {
                    return
                }

                if (mc.thePlayer.onGround) {
                    mc.thePlayer.hurtTime <= 6 && (mc.thePlayer.motionX *= 0.600151164, mc.thePlayer.motionZ *= 0.600151164);
                    mc.thePlayer.hurtTime <= 4 && (mc.thePlayer.motionX *= 0.700151164, mc.thePlayer.motionZ *= 0.700151164);

                } else if (mc.thePlayer.hurtTime <= 9) {
                    mc.thePlayer.motionX *= 0.6001421204;
                    mc.thePlayer.motionZ *= 0.6001421204;
                }

                break;
            case "HytTest2":
                if (mc.thePlayer.hurtTime <= 0 && !velocityInput) {
                    return
                }

                if (mc.thePlayer.onGround) {
                    mc.thePlayer.hurtTime <= 6 && (mc.thePlayer.motionX *= 0.600151164, mc.thePlayer.motionZ *= 0.600151164);
                    mc.thePlayer.hurtTime <= 4 && (mc.thePlayer.motionX *= 0.700151164, mc.thePlayer.motionZ *= 0.700151164);

                } else if (mc.thePlayer.hurtTime <= 9) {
                    mc.thePlayer.motionX *= 0.6001421204;
                    mc.thePlayer.motionZ *= 0.6001421204;
                }

                break;
            case "HytTest4":
                if (mc.thePlayer.hurtTime == 0 && !velocityInput) {
                    return
                }
                if (mc.thePlayer.onGround) {
                    mc.thePlayer.hurtTime <= 6 && (mc.thePlayer.motionX *= 0.600151164, mc.thePlayer.motionZ *= 0.600151164);
                    mc.thePlayer.hurtTime <= 4 && (mc.thePlayer.motionX *= 0.700151164, mc.thePlayer.motionZ *= 0.700151164);
                } else if (mc.thePlayer.hurtTime <= 9) {
                    mc.thePlayer.motionX *= 0.6001421204;
                    mc.thePlayer.motionZ *= 0.6001421204;
                } else {
				    mc.thePlayer.motionX = 0;
					mc.thePlayer.motionZ = 0;
				}
                break;				
            case "HytNew":
                if (mc.thePlayer.hurtTime == 0 && !velocityInput) {
                    return
                }
                if (mc.thePlayer.onGround) {
                    mc.thePlayer.hurtTime <= 6 && (mc.thePlayer.motionX *= 0.600151164, mc.thePlayer.motionZ *= 0.600151164);
                    mc.thePlayer.hurtTime <= 4 && (mc.thePlayer.motionX *= 0.700151164, mc.thePlayer.motionZ *= 0.700151164);
                } else if (mc.thePlayer.hurtTime <= 9) {
                    mc.thePlayer.motionX *= 0.6001421204;
                    mc.thePlayer.motionZ *= 0.6001421204;
                }
                break;
            case "Push":
                if (mc.thePlayer.hurtTime <= 0 && !velocityInput) {
                    return;
                }

                var reduce = pushResetValue.get();

                if (jump) {
                    jump = !mc.thePlayer.onGround;
                } else {
                    mc.thePlayer.motionY -= pushYResetValue.get();
                }

                mc.thePlayer.motionX /= reduce;
                mc.thePlayer.motionZ /= reduce;
                break;
        }
    });

    module.on("jump", function(event) {
        if (module.settings.mode.get() == "Push") {
            jump = true;
            if (mc.thePlayer.CollidedVer) return;
            event.cancelEvent();
            return;
        }
    });

    module.on("packet", function(event) {
        var packet = event.getPacket();
        if (packet instanceof S12PacketEntityVelocity) {
            if (module.settings.debug.get()) {
                chat.print("§b[Debug]§cX:" + packet.getMotionX() + "§cY:" + packet.getMotionY() + "§cZ:" + packet.getMotionZ());
            }
            velocityInput = true
            switch (module.settings.mode.get()) {
                case "Simple":
                    if (module.settings.SimpleCancel.get()) {
                        event.cancelEvent();
                    }
                    packet.motionX = packet.getMotionX() * (module.settings.xVel.get() / 100);
                    packet.motionY = packet.getMotionY() * (module.settings.yVel.get() / 100);
                    packet.motionZ = packet.getMotionZ() * (module.settings.zVel.get() / 100);
                    break;
                case "AAC5Simple":
                    if (module.settings.SimpleCancel.get()) {
                        event.cancelEvent();
                    }

                    if (module.settings.simpleValue.get()) {
                        if (!mc.thePlayer.onGround || !module.settings.hytOnlyGround.get()) {
                            return
                        }

                        packet.motionX = packet.getMotionX() * (module.settings.xVel.get() / 100);
                        packet.motionZ = packet.getMotionZ() * (module.settings.zVel.get() / 100);

                    } else {
                        packet.motionX = packet.getMotionX() * (module.settings.xVel.get() / 100);
                        packet.motionY = packet.getMotionY() * (module.settings.yVel.get() / 100);
                        packet.motionZ = packet.getMotionZ() * (module.settings.zVel.get() / 100);
                    }

                    if (!mc.thePlayer.onGround && module.settings.hytOnlyGround.get()) {
                        return
                    }

                    if (packet.motionX < 300 && packet.motionY < 300) {
                        return
                    }

                    mc.netHandler.addToSendQueue(new C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY - module.settings.HeightValue.get(), mc.thePlayer.posZ, true))

                    mc.netHandler.addToSendQueue(new C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY - 0.1442111, mc.thePlayer.posZ, false))

                    event.cancelEvent()
                    packet.motionX = 0
                    packet.motionY = 0.05
                    packet.motionZ = 0
                    break;
                case "Cancel":
                    event.cancelEvent();
                    break;
                case "Clean":
                    if (mc.thePlayer.hurtTime >= 0) {
                        packet.motionX = 0
                        packet.motionY = 0
                        packet.motionZ = 0
                        if (packet instanceof C03PacketPlayer) {
                            packet.y += 0.11451419198;
                        }
                    } else {
                        if (packet instanceof C03PacketPlayer) {
                            packet.y += 0.11451419198;
                        }
                        packet.motionX = 0
                        packet.motionY = 0
                        packet.motionZ = 0
                    }
                    break;
                case "HytSpoof":
                    if (mc.thePlayer.hurtTime != 0) {
                        event.cancelEvent()
                    } else {
                        packet.motionX = 0
                        packet.motionY = 0
                        packet.motionZ = 0
                    }
                    break;
                case "HytTest":
                    if (mc.thePlayer.hurtTime != 0) {
                        event.cancelEvent()
                    } else {
                        packet.motionX = 0
                        packet.motionY = 0
                        packet.motionZ = 0
                    }
                    break;
                case "HytTest2":
                    event.cancelEvent()
                    break;
                case "HytNew":
                    if (mc.thePlayer.hurtTime != 0) {
                        event.cancelEvent();
                        packet.motionX = 0
                        packet.motionY = 0
                        packet.motionZ = 0

                        if (module.settings.c03packet.get()) {
                            if (packet instanceof C03PacketPlayer) {
                                packet.y += 0.11451419198;
                            }
                        } else {
                            if (packet instanceof C03PacketPlayer) {
                                packet.y += 0.11451419198;
                            }
                        }
                    } else {
                        packet.motionX = 0
                        packet.motionY = 0
                        packet.motionZ = 0
                        packet.y += 0.11451419198
                    }
                    break;
                case "HytTest3":
                    if (mc.thePlayer.hurtTime != 0) {
                        event.cancelEvent();
                        packet.motionX = 0
                        packet.motionY = 0
                        packet.motionZ = 0

                        if (module.settings.c03packet.get()) {
                            if (packet instanceof C03PacketPlayer) {
                                packet.y += 0.11451419198;
                            }
                        } else {
                            if (packet instanceof C03PacketPlayer) {
                                packet.y += 0.11451419198;
                            }
                        }
                    } else {
                        packet.motionX = 0
                        packet.motionY = 0
                        packet.motionZ = 0
                        packet.y += 0.11451419198
                    }
                    break;					
            }
        }
		
        if (packet instanceof S27PacketExplosion && module.settings.cancelS27.get()) {
			event.cancelEvent()
		}

       if(module.settings.disreset2.get() && DisableReset) {
            packet.motionX = 0
            packet.motionY = 0
            packet.motionZ = 0
      }
    });

    module.on("disable", function() {
        mc.timer.timerSpeed = 1
          DisableReset = true;
          if(module.settings.disreset.get()) {
            mc.thePlayer.motionX = 0;
            mc.thePlayer.motionZ = 0;
            mc.thePlayer.motionY = 0;
          }		
    });

});