﻿var scriptName = "confings";
var scriptVersion = 1.0;
var scriptAuthor = "confings"
var confings = new confings();
var client;

function confings() {
	var MovementUtils = Java.type('net.ccbluex.liquidbounce.utils.MovementUtils')
	var ArrayList = Java.type('java.util.ArrayList');
	var LinkedList = Java.type('java.util.LinkedList');
    this.getName = function() {
        return "confings";
    };
    
	this.getDescription = function() {
        return "confings.";
    };
    
	this.getCategory = function() {
        return "Miuc";
	};
	
	this.getTag = function() {
		return "Config By San Of Yurlu";
	};
}
function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(confings);
}

function onDisable() {
    moduleManager.unregisterModule(client);
}