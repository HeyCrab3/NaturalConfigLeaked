var scriptName = "KeepArmor";
var scriptVersion = 0.1;
var scriptAuthor = "mumy"
var GuiInventory = Java.type("net.minecraft.client.gui.inventory.GuiInventory");
var C0DPacketCloseWindow = Java.type("net.minecraft.network.play.client.C0DPacketCloseWindow");
var C16PacketClientStatus = Java.type("net.minecraft.network.play.client.C16PacketClientStatus");

function KeepArmor() {

    var setting = {
        float: function (name, def, min, max) {
            return value.createFloat(name, def, min, max);
        },
        text: function (name, def) {
            return value.createText(name, def);
        }
    };

    var settings = {
        health: setting.float("Health", 5, 0, 20),
        command: setting.text("Command", "/hub")
    };

    var state = false;
    var world = null;
    var count = 0;

    this.getName = function () {
        return "KeepArmor";
    }

    this.getDescription = function () {
        return "KeepArmor-Module,by-mumy";
    }

    this.getCategory = function () {
        return "Misc";
    }

    this.onEnable = function () {
        reset();
    }

    this.onDisable = function () {
        this.onEnable();
    }

    this.onUpdate = function () {
        if (state && count < 5) {
            if (world === mc.theWorld) {
                ++count;
            }
            state = false;
            mc.thePlayer.sendChatMessage(settings.command.get());
        } if (mc.thePlayer.getHealth() < settings.health.get()) {
            var openInventory = !(mc.currentScreen instanceof GuiInventory);
            openInventory && mc.netHandler.addToSendQueue(new C16PacketClientStatus(C16PacketClientStatus.EnumState.OPEN_INVENTORY_ACHIEVEMENT));
            for (var i = 5; i >= 0; --i) {
                var armorSlot = i;
                move(8 - armorSlot);
            }
            openInventory && mc.netHandler.addToSendQueue(new C0DPacketCloseWindow());
            state = true;
            world = mc.theWorld;
        }
    }

    this.onWorld = function () {
        reset();
    }

    this.addValues = function (values) {
        for (var i in settings) {
            values.add(settings[i]);
        }
    }

    function move(item) {
        item !== -1 && mc.playerController.windowClick(mc.thePlayer.openContainer.windowId, item, 0, 1, mc.thePlayer);
    }

    function reset() {
        state = false;
        world = null;
        count = 0;
    }

}

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(new KeepArmor());
}

function onDisable() {
    moduleManager.unregisterModule(client);
}