R杀戮+反击退
Z逃逸
F飞行逃逸
Vspeed
X刀暴